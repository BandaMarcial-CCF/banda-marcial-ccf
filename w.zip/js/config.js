// Configuração pública do Supabase (a chave "anon" é pública por design; quem protege os dados é o RLS do banco).
// NUNCA coloque aqui a chave "service_role".
window.CFG = {
  url: "COLE_AQUI_A_URL_DO_PROJETO",
  key: "COLE_AQUI_A_CHAVE_ANON_PUBLICA",
  admin: "igortb.zimba@gmail.com" // usado só para mostrar/esconder a aba Admin; a permissão real é validada no banco
};
